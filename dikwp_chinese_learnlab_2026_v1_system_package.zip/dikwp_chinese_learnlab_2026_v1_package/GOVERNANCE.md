# Governance and Safety Boundary

## Prohibited uses
- issuing official HSK/YCT/ACTFL/CEFR/AP certificates
- high-stakes placement, admissions, visa, scholarship or employment decisions
- hidden recording, classroom surveillance, biometric scoring or accent shaming
- inferring ethnicity, nationality, heritage identity or ability from appearance or name
- uploading minors' personal data without guardian/institutional authorization
- AI ghostwriting of assignments or official exam answers

## Required safeguards
- transparent AI-use rules
- learner-visible evidence ledger
- human teacher/peer review for important judgments
- privacy-minimized recordings
- right to explain, correct and appeal
- no shame-based correction of accents or heritage gaps

## Kill conditions
Stop or downgrade the workflow if AI output is being used as a final answer, if recordings are collected secretly, if the learner cannot reproduce output without AI, or if a task becomes high-stakes.
