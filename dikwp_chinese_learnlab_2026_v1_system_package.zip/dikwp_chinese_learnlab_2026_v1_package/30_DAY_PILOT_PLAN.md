# 30-Day Pilot Plan

Week 1: learner profiles, purpose, AI rules, baseline tone/hanzi/input/output evidence.
Week 2: tone pair drills, hanzi component cards, vocabulary chunks and graded input.
Week 3: speaking/writing output tasks, Error Ledger and AI Use Log.
Week 4: teacher/peer review, closed-AI retell/rewrite and Chinese Learning Passport.

Acceptance criteria: no official certification claims; at least 5 evidence items; at least 10 closed errors; at least 1 speaking recording, 1 writing draft chain and 1 AI Use Log; human review completed.
