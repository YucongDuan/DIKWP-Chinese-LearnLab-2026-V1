#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from datetime import datetime, timezone

def main():
    p=argparse.ArgumentParser();p.add_argument('learner',type=Path);p.add_argument('--out',type=Path,default=Path('outputs'));args=p.parse_args()
    learner=json.loads(args.learner.read_text(encoding='utf-8'))
    hours=int(learner.get('weekly_hours',5))
    mix={'pinyin_tones':20,'hanzi':24,'vocab_chunks':20,'input':18,'output':12,'culture':6}
    if hours>=8: mix.update({'pinyin_tones':15,'hanzi':24,'vocab_chunks':20,'input':20,'output':16,'culture':5})
    passport={'version':'DIKWP Chinese LearnLab 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'learner':learner,'recommended_weekly_mix':mix,'required_controls':['evidence ledger','error ledger','AI use log','teacher or peer review','closed-AI retell/rewrite'],'boundaries':{'official_certificate':False,'high_stakes_placement':False,'hidden_recording':False,'human_teacher_review_required':True}}
    args.out.mkdir(parents=True,exist_ok=True);target=args.out/f"{learner.get('learner_id','learner')}_chinese_learning_passport.json";target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DIKWP Chinese LearnLab 2026 V1');print('Output:',target)
if __name__=='__main__': main()
