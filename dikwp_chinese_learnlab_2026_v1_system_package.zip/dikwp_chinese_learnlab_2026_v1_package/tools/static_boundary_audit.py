#!/usr/bin/env python3
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PAT=[(r"\brequests\.","network"),(r"\burllib\.request","url"),(r"\bsocket\.","socket"),(r"\beval\(","eval"),(r"\bexec\(","exec"),(r"navigator\.mediaDevices","camera/mic"),(r"localStorage","browser storage")]
EX={'static_boundary_audit.py','static_boundary_audit_report.json'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EX or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pat,meaning in PAT:
            if re.search(pat,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
    out={'package':'DIKWP Chinese LearnLab 2026 V1','findings':findings,'network_or_hidden_capture_detected':bool(findings),'note':'No external model calls, hidden recording, LMS writeback, or official certification adapters are included.'}
    (ROOT/'static_boundary_audit_report.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
