# NOTICE

DIKWP Chinese LearnLab 2026 V1 is a synthetic-data reference implementation for Chinese-as-a-second-language learning, teacher development, course design, and GitHub demonstration.

It is not an official HSK/YCT/AP/ACTFL/CEFR test, rating, credential, or placement engine.
