# Sources
- ChineseTest official HSK and YCT pages.
- Chinese Proficiency Grading Standards for International Chinese Language Education, Three Stages and Nine Levels.
- ACTFL Proficiency Guidelines 2024 and World-Readiness Standards.
- Council of Europe CEFR Companion Volume 2020.
- College Board AP Chinese Language and Culture course and exam pages.
- U.S. Foreign Service Institute language difficulty categories.

All official exam requirements and dates must be verified from official test centers before high-stakes use.
